from flask import Blueprint, request, jsonify
from src.models.question import db, Question, Answer, Vote
from datetime import datetime

questions_bp = Blueprint('questions', __name__)

@questions_bp.route('/questions', methods=['GET'])
def get_questions():
    """Obter todas as perguntas com filtros opcionais"""
    try:
        category = request.args.get('category')
        search = request.args.get('search')
        sort_by = request.args.get('sort', 'created_at')  # created_at, votes
        order = request.args.get('order', 'desc')  # asc, desc
        
        query = Question.query
        
        # Filtrar por categoria
        if category and category != 'Todas':
            query = query.filter(Question.category == category)
        
        # Filtrar por busca
        if search:
            search_term = f"%{search}%"
            query = query.filter(
                db.or_(
                    Question.title.ilike(search_term),
                    Question.content.ilike(search_term)
                )
            )
        
        # Ordenar
        if sort_by == 'votes':
            if order == 'desc':
                query = query.order_by(Question.votes.desc())
            else:
                query = query.order_by(Question.votes.asc())
        else:  # created_at
            if order == 'desc':
                query = query.order_by(Question.created_at.desc())
            else:
                query = query.order_by(Question.created_at.asc())
        
        questions = query.all()
        return jsonify([q.to_dict() for q in questions])
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@questions_bp.route('/questions', methods=['POST'])
def create_question():
    """Criar uma nova pergunta"""
    try:
        data = request.get_json()
        
        if not data or not data.get('title') or not data.get('content'):
            return jsonify({'error': 'Título e conteúdo são obrigatórios'}), 400
        
        question = Question(
            title=data['title'],
            content=data['content'],
            author=data.get('author', 'Anônimo'),
            category=data.get('category', 'Geral')
        )
        
        db.session.add(question)
        db.session.commit()
        
        return jsonify(question.to_dict()), 201
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@questions_bp.route('/questions/<int:question_id>', methods=['GET'])
def get_question(question_id):
    """Obter uma pergunta específica com suas respostas"""
    try:
        question = Question.query.get_or_404(question_id)
        answers = Answer.query.filter_by(question_id=question_id).order_by(Answer.votes.desc()).all()
        
        result = question.to_dict()
        result['answers'] = [answer.to_dict() for answer in answers]
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@questions_bp.route('/questions/<int:question_id>/answers', methods=['POST'])
def create_answer(question_id):
    """Criar uma resposta para uma pergunta"""
    try:
        question = Question.query.get_or_404(question_id)
        data = request.get_json()
        
        if not data or not data.get('content'):
            return jsonify({'error': 'Conteúdo é obrigatório'}), 400
        
        answer = Answer(
            content=data['content'],
            author=data.get('author', 'Anônimo'),
            question_id=question_id
        )
        
        db.session.add(answer)
        db.session.commit()
        
        return jsonify(answer.to_dict()), 201
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@questions_bp.route('/questions/<int:question_id>/vote', methods=['POST'])
def vote_question(question_id):
    """Votar em uma pergunta"""
    try:
        question = Question.query.get_or_404(question_id)
        data = request.get_json()
        
        if not data or data.get('vote_type') not in ['up', 'down']:
            return jsonify({'error': 'Tipo de voto inválido'}), 400
        
        user_id = request.remote_addr  # Usar IP como identificador temporário
        vote_type = data['vote_type']
        
        # Verificar se já existe um voto
        existing_vote = Vote.query.filter_by(
            user_id=user_id,
            question_id=question_id
        ).first()
        
        if existing_vote:
            if existing_vote.vote_type == vote_type:
                # Remover voto se for o mesmo tipo
                if vote_type == 'up':
                    question.votes -= 1
                else:
                    question.votes += 1
                db.session.delete(existing_vote)
            else:
                # Mudar tipo de voto
                if vote_type == 'up':
                    question.votes += 2
                else:
                    question.votes -= 2
                existing_vote.vote_type = vote_type
        else:
            # Novo voto
            if vote_type == 'up':
                question.votes += 1
            else:
                question.votes -= 1
            
            new_vote = Vote(
                user_id=user_id,
                question_id=question_id,
                vote_type=vote_type
            )
            db.session.add(new_vote)
        
        db.session.commit()
        
        return jsonify({
            'votes': question.votes,
            'user_vote': vote_type if not (existing_vote and existing_vote.vote_type == vote_type) else None
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@questions_bp.route('/answers/<int:answer_id>/vote', methods=['POST'])
def vote_answer(answer_id):
    """Votar em uma resposta"""
    try:
        answer = Answer.query.get_or_404(answer_id)
        data = request.get_json()
        
        if not data or data.get('vote_type') not in ['up', 'down']:
            return jsonify({'error': 'Tipo de voto inválido'}), 400
        
        user_id = request.remote_addr
        vote_type = data['vote_type']
        
        existing_vote = Vote.query.filter_by(
            user_id=user_id,
            answer_id=answer_id
        ).first()
        
        if existing_vote:
            if existing_vote.vote_type == vote_type:
                if vote_type == 'up':
                    answer.votes -= 1
                else:
                    answer.votes += 1
                db.session.delete(existing_vote)
            else:
                if vote_type == 'up':
                    answer.votes += 2
                else:
                    answer.votes -= 2
                existing_vote.vote_type = vote_type
        else:
            if vote_type == 'up':
                answer.votes += 1
            else:
                answer.votes -= 1
            
            new_vote = Vote(
                user_id=user_id,
                answer_id=answer_id,
                vote_type=vote_type
            )
            db.session.add(new_vote)
        
        db.session.commit()
        
        return jsonify({
            'votes': answer.votes,
            'user_vote': vote_type if not (existing_vote and existing_vote.vote_type == vote_type) else None
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@questions_bp.route('/categories', methods=['GET'])
def get_categories():
    """Obter todas as categorias disponíveis"""
    try:
        categories = db.session.query(Question.category).distinct().all()
        category_list = ['Todas'] + [cat[0] for cat in categories]
        return jsonify(category_list)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@questions_bp.route('/stats', methods=['GET'])
def get_stats():
    """Obter estatísticas do site"""
    try:
        total_questions = Question.query.count()
        total_answers = Answer.query.count()
        total_votes = Vote.query.count()
        
        return jsonify({
            'total_questions': total_questions,
            'total_answers': total_answers,
            'total_votes': total_votes,
            'active_users': 42  # Valor fixo por enquanto
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

