// Configuração da API
const API_BASE_URL = import.meta.env.PROD 
  ? 'https://bingus-qa-backend.railway.app' // URL do backend em produção
  : '/api' // URL local para desenvolvimento

export { API_BASE_URL }

