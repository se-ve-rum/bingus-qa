import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog.jsx'
import { Heart, MessageCircle, Search, Plus, ChevronUp, ChevronDown, User, Star, Clock, TrendingUp, Send } from 'lucide-react'
import { API_BASE_URL } from './config.js'
import bingusMain from './assets/bingus/bingus_main.png'
import bingusIcon from './assets/bingus/bingus_icon.png'
import './App.css'

function App() {
  const [questions, setQuestions] = useState([])
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('Todas')
  const [newQuestion, setNewQuestion] = useState({ title: '', content: '', category: 'Geral' })
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [selectedQuestion, setSelectedQuestion] = useState(null)
  const [questionAnswers, setQuestionAnswers] = useState([])
  const [newAnswer, setNewAnswer] = useState('')
  const [isAnswerDialogOpen, setIsAnswerDialogOpen] = useState(false)
  const [stats, setStats] = useState({ total_questions: 0, total_answers: 0, active_users: 42 })

  const categories = ['Todas', 'Características', 'História', 'Debate', 'Geral', 'Curiosidades', 'Memes']

  // Carregar perguntas da API
  useEffect(() => {
    fetchQuestions()
    fetchStats()
  }, [selectedCategory, searchTerm])

  const fetchQuestions = async () => {
    try {
      const params = new URLSearchParams()
      if (selectedCategory !== 'Todas') params.append('category', selectedCategory)
      if (searchTerm) params.append('search', searchTerm)
      
      const response = await fetch(`${API_BASE_URL}/questions?${params}`)
      const data = await response.json()
      setQuestions(data.map(q => ({
        ...q,
        date: new Date(q.created_at).toLocaleDateString('pt-BR'),
        answers: q.answers_count,
        userVote: null
      })))
    } catch (error) {
      console.error('Erro ao carregar perguntas:', error)
    }
  }

  const fetchStats = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/stats`)
      const data = await response.json()
      setStats(data)
    } catch (error) {
      console.error('Erro ao carregar estatísticas:', error)
    }
  }

  const fetchQuestionDetails = async (questionId) => {
    try {
      const response = await fetch(`${API_BASE_URL}/questions/${questionId}`)
      const data = await response.json()
      setSelectedQuestion(data)
      setQuestionAnswers(data.answers || [])
    } catch (error) {
      console.error('Erro ao carregar detalhes da pergunta:', error)
    }
  }

  const handleVote = async (questionId, voteType) => {
    try {
      const response = await fetch(`${API_BASE_URL}/questions/${questionId}/vote`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ vote_type: voteType })
      })
      const data = await response.json()
      
      setQuestions(questions.map(question => {
        if (question.id === questionId) {
          return { ...question, votes: data.votes, userVote: data.user_vote }
        }
        return question
      }))
    } catch (error) {
      console.error('Erro ao votar:', error)
    }
  }

  const handleSubmitQuestion = async () => {
    if (newQuestion.title.trim() && newQuestion.content.trim()) {
      try {
        const response = await fetch(`${API_BASE_URL}/questions`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            title: newQuestion.title,
            content: newQuestion.content,
            category: newQuestion.category,
            author: 'Usuário'
          })
        })
        
        if (response.ok) {
          setNewQuestion({ title: '', content: '', category: 'Geral' })
          setIsDialogOpen(false)
          fetchQuestions()
          fetchStats()
        }
      } catch (error) {
        console.error('Erro ao criar pergunta:', error)
      }
    }
  }

  const handleSubmitAnswer = async () => {
    if (newAnswer.trim() && selectedQuestion) {
      try {
        const response = await fetch(`${API_BASE_URL}/questions/${selectedQuestion.id}/answers`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            content: newAnswer,
            author: 'Usuário'
          })
        })
        
        if (response.ok) {
          setNewAnswer('')
          fetchQuestionDetails(selectedQuestion.id)
          fetchQuestions()
          fetchStats()
        }
      } catch (error) {
        console.error('Erro ao enviar resposta:', error)
      }
    }
  }

  const openAnswerDialog = (question) => {
    setSelectedQuestion(question)
    fetchQuestionDetails(question.id)
    setIsAnswerDialogOpen(true)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-white to-blue-50">
      {/* Header */}
      <header className="bingus-gradient shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <img 
                src={bingusIcon} 
                alt="Bingus" 
                className="w-12 h-12 rounded-full bingus-float easter-egg"
                onClick={() => alert('Miau! 🐱')}
              />
              <div>
                <h1 className="text-3xl font-bold text-white">Bingus Q&A</h1>
                <p className="text-pink-100">Perguntas e Respostas sobre nosso gato favorito</p>
              </div>
            </div>
            <div className="hidden md:block">
              <img 
                src={bingusMain} 
                alt="Bingus Principal" 
                className="w-20 h-24 object-cover rounded-lg bingus-pulse"
              />
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Card className="bingus-card mb-6">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Search className="w-5 h-5" />
                  Buscar
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Input
                  placeholder="Buscar perguntas..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="search-input"
                />
              </CardContent>
            </Card>

            <Card className="bingus-card mb-6">
              <CardHeader>
                <CardTitle>Categorias</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {categories.map(category => (
                    <Button
                      key={category}
                      variant={selectedCategory === category ? "default" : "ghost"}
                      className="w-full justify-start"
                      onClick={() => setSelectedCategory(category)}
                    >
                      {category}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bingus-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  Estatísticas
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Total de Perguntas</span>
                    <Badge variant="secondary">{stats.total_questions}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Respostas</span>
                    <Badge variant="secondary">{stats.total_answers}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Usuários Ativos</span>
                    <Badge variant="secondary">{stats.active_users}</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold">
                {selectedCategory === 'Todas' ? 'Todas as Perguntas' : `Categoria: ${selectedCategory}`}
              </h2>
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bingus-hover">
                    <Plus className="w-4 h-4 mr-2" />
                    Nova Pergunta
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Fazer uma Nova Pergunta</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium">Título</label>
                      <Input
                        placeholder="Digite o título da sua pergunta..."
                        value={newQuestion.title}
                        onChange={(e) => setNewQuestion({...newQuestion, title: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Categoria</label>
                      <select 
                        className="w-full p-2 border rounded-md"
                        value={newQuestion.category}
                        onChange={(e) => setNewQuestion({...newQuestion, category: e.target.value})}
                      >
                        {categories.slice(1).map(cat => (
                          <option key={cat} value={cat}>{cat}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="text-sm font-medium">Conteúdo</label>
                      <Textarea
                        placeholder="Descreva sua pergunta em detalhes..."
                        value={newQuestion.content}
                        onChange={(e) => setNewQuestion({...newQuestion, content: e.target.value})}
                        rows={4}
                      />
                    </div>
                    <Button onClick={handleSubmitQuestion} className="w-full">
                      Publicar Pergunta
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            {/* Questions List */}
            <div className="space-y-4">
              {questions.map(question => (
                <Card key={question.id} className="question-card bingus-hover">
                  <CardContent className="p-6">
                    <div className="flex gap-4">
                      {/* Vote Section */}
                      <div className="flex flex-col items-center space-y-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          className={`vote-button ${question.userVote === 'up' ? 'active' : ''}`}
                          onClick={() => handleVote(question.id, 'up')}
                        >
                          <ChevronUp className="w-5 h-5" />
                        </Button>
                        <span className="font-bold text-lg">{question.votes}</span>
                        <Button
                          variant="ghost"
                          size="sm"
                          className={`vote-button ${question.userVote === 'down' ? 'active' : ''}`}
                          onClick={() => handleVote(question.id, 'down')}
                        >
                          <ChevronDown className="w-5 h-5" />
                        </Button>
                      </div>

                      {/* Question Content */}
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-2">
                          <h3 className="text-xl font-semibold hover:text-primary cursor-pointer">
                            {question.title}
                          </h3>
                          <Badge className="category-tag">{question.category}</Badge>
                        </div>
                        <p className="text-muted-foreground mb-4">{question.content}</p>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-4">
                            <div className="flex items-center space-x-2">
                              <Avatar className="w-6 h-6 user-avatar">
                                <AvatarFallback>{question.author[0]}</AvatarFallback>
                              </Avatar>
                              <span className="text-sm text-muted-foreground">{question.author}</span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <Clock className="w-4 h-4 text-muted-foreground" />
                              <span className="text-sm text-muted-foreground">{question.date}</span>
                            </div>
                          </div>
                          
                          <div className="flex items-center space-x-4">
                            <div className="flex items-center space-x-1">
                              <MessageCircle className="w-4 h-4 text-muted-foreground" />
                              <span className="text-sm text-muted-foreground">{question.answers} respostas</span>
                            </div>
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="bingus-hover"
                              onClick={() => openAnswerDialog(question)}
                            >
                              Responder
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {questions.length === 0 && (
              <Card className="bingus-card">
                <CardContent className="p-12 text-center">
                  <img 
                    src={bingusIcon} 
                    alt="Bingus Triste" 
                    className="w-16 h-16 mx-auto mb-4 opacity-50"
                  />
                  <h3 className="text-xl font-semibold mb-2">Nenhuma pergunta encontrada</h3>
                  <p className="text-muted-foreground">
                    Tente ajustar sua busca ou seja o primeiro a fazer uma pergunta sobre este tópico!
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>

      {/* Dialog para Responder Pergunta */}
      <Dialog open={isAnswerDialogOpen} onOpenChange={setIsAnswerDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {selectedQuestion?.title}
            </DialogTitle>
          </DialogHeader>
          
          {selectedQuestion && (
            <div className="space-y-6">
              {/* Pergunta Original */}
              <Card className="bingus-card">
                <CardContent className="p-4">
                  <p className="text-muted-foreground mb-3">{selectedQuestion.content}</p>
                  <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                    <span>Por: {selectedQuestion.author}</span>
                    <span>Categoria: {selectedQuestion.category}</span>
                    <span>{selectedQuestion.votes} votos</span>
                  </div>
                </CardContent>
              </Card>

              {/* Respostas Existentes */}
              {questionAnswers.length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold mb-4">
                    Respostas ({questionAnswers.length})
                  </h3>
                  <div className="space-y-3">
                    {questionAnswers.map(answer => (
                      <Card key={answer.id} className="bingus-card">
                        <CardContent className="p-4">
                          <p className="mb-3">{answer.content}</p>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                              <Avatar className="w-5 h-5 user-avatar">
                                <AvatarFallback>{answer.author[0]}</AvatarFallback>
                              </Avatar>
                              <span>{answer.author}</span>
                              <span>•</span>
                              <span>{new Date(answer.created_at).toLocaleDateString('pt-BR')}</span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <span className="text-sm font-medium">{answer.votes}</span>
                              <span className="text-sm text-muted-foreground">votos</span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              )}

              {/* Nova Resposta */}
              <div>
                <h3 className="text-lg font-semibold mb-4">Sua Resposta</h3>
                <div className="space-y-4">
                  <Textarea
                    placeholder="Digite sua resposta aqui..."
                    value={newAnswer}
                    onChange={(e) => setNewAnswer(e.target.value)}
                    rows={4}
                    className="resize-none"
                  />
                  <div className="flex justify-end space-x-2">
                    <Button 
                      variant="outline" 
                      onClick={() => setIsAnswerDialogOpen(false)}
                    >
                      Cancelar
                    </Button>
                    <Button 
                      onClick={handleSubmitAnswer}
                      disabled={!newAnswer.trim()}
                      className="bingus-hover"
                    >
                      <Send className="w-4 h-4 mr-2" />
                      Enviar Resposta
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Footer */}
      <footer className="bg-gray-100 mt-16">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <img src={bingusIcon} alt="Bingus" className="w-8 h-8 rounded-full" />
              <span className="font-semibold">Bingus Q&A</span>
            </div>
            <p className="text-muted-foreground">
              Feito com ❤️ para a comunidade Bingus
            </p>
            <p className="text-sm text-muted-foreground mt-2">
              © 2024 Bingus Q&A. Todos os direitos reservados ao nosso gato careca favorito.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App

